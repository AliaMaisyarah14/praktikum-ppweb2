<?php
    // mendefinisikan variables
    $nama = "Alia";
    $umur = 21;
    $bb = 45;

    echo "Nama saya adalah : " .$nama;
    echo "<br/>Umur : " .$umur. " Tahun";
    echo "<br/>Berat badab : " .$bb. " kg";
?>